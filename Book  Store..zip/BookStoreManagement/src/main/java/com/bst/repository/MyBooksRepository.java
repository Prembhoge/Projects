package com.bst.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bst.entity.MyBookList;

@Repository
public interface MyBooksRepository extends JpaRepository<MyBookList, Integer> 
{
	
}
