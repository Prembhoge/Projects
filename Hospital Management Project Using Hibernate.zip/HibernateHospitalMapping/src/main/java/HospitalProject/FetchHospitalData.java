package HospitalProject;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
public class FetchHospitalData {
	public static void main(String[] args) {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("mru");
		EntityManager em =emf.createEntityManager();
		
		Scanner sc= new Scanner(System.in);
		System.out.println("1.Details of Hospital   2.Details of Branches");
		switch(sc.nextInt())
		{
		case 1 :
		{
			System.out.println("Hospital details......");
			Hospital h  = em.find(Hospital.class, 1);
			System.out.println("Hospital id is "+h.getId());
			System.out.println("Hospital name is "+h.getName());
			System.out.println("----------------------------");
			
			System.out.println("Branch details......");
			List<Branch> br = h.getBranches();
			Branch b = br.get(0);
			System.out.println("Branch id is "+b.getId());
			System.out.println("Branch name is "+b.getName());
			System.out.println("----------------------------");
			
			System.out.println("Address details......");
			
			Address a = b.getA();
			System.out.println("Address id is "+a.getId());
			System.out.println("Address name is "+a.getAddress());
			System.out.println("----------------------------");
			
			System.out.println("Record details......");
			List<Record> re = b.getRecords();
			Record r1 = re.get(0);
			System.out.println("Record id is "+r1.getId());
			System.out.println("Record Name. is "+r1.getName());
			System.out.println("Record Time is "+r1.getTime());
			System.out.println(" Record Sysmptoms is "+r1.getSysmptoms());
			System.out.println("----------------------------");
			
			System.out.println("Patient details......");
			Patient p1 = r1.getP();
			System.out.println("Patient id is "+p1.getId());
			System.out.println("Patient name is "+p1.getPname());
			System.out.println("----------------------------");
			
			System.out.println("Disease details......");
			List<Disease> di = p1.getDiseaes();
			Disease d1 = di.get(0);
			System.out.println("Disease id is "+d1.getId());
			System.out.println("Disease name is "+d1.getDname());
			System.out.println("----------------------------");
			
		break;
		}
		case 2 :
		{
			System.out.println("Branch details......");
			Hospital h = em.find(Hospital.class, 1);
			List<Branch> br = h.getBranches();
			Branch b = br.get(0);
			System.out.println("Branch id is "+b.getId());
			System.out.println("Branch name is "+b.getName());
			System.out.println("----------------------------");
			
			System.out.println("Address details......");
			Address a = b.getA();
			System.out.println("Address id is "+a.getId());
			System.out.println("Address name is "+a.getAddress());
			System.out.println("----------------------------");
			
			
		}
			
		}
		
		

	}

}



