package HospitalProject;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
@Entity
public class Patient {
	@Id
	private int id;
	private String pname;
	@ManyToMany
	private List<Disease>diseaes;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public List<Disease> getDiseaes() {
		return diseaes;
	}
	public void setDiseaes(List<Disease> diseaes) {
		this.diseaes = diseaes;
	}
	
}
