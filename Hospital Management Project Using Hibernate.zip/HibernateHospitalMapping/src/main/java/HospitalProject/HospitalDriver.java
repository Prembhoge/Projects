package HospitalProject;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


public class HospitalDriver {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mru");
		 EntityManager em = emf.createEntityManager();
		 EntityTransaction et =em.getTransaction();
	
	Hospital h = new Hospital();
	h.setId(1);
	h.setName("Sanjivani");
	 
	 Branch b= new Branch();
	 b.setId(1);
	 b.setName("Pune");
	 
	 Branch b1= new Branch();
	 b1.setId(2);
	 b1.setName("Mumbai");
	 
	 Branch b2= new Branch();
	 b2.setId(3);
	 b2.setName("Nashik");

	 List<Branch>branches = new ArrayList<Branch>();
	 branches.add(b);
	 branches.add(b1);
	 branches.add(b2);

     
      Address a = new Address();
      a.setId(1);
      a.setAddress("Shivaji Nagar");
      
      Address a1 = new Address();
      a1.setId(2);
      a1.setAddress("Vashi");
      Address a2 = new Address();
      a2.setId(3);
      a2.setAddress("Hingne Colony");
      
     
 	 List<Address>address = new ArrayList<Address>();
 	 address.add(a);
 	 address.add(a1);
 	 address.add(a2);
      
      Record r = new Record();
      r.setId(1);
      r.setName("Mona");
      r.setTime(12.00);
      r.setSysmptoms("Fever");
      
      Record r1 = new Record();
      r1.setId(2);
      r1.setName("Yash");
      r1.setTime(3.00);
      r1.setSysmptoms("Cold");
      
      Record r2 = new Record();
      r2.setId(3);
      r2.setName("Vrunda");
      r2.setTime(4.00);
      r2.setSysmptoms("LegPain");
      
      List<Record>records = new ArrayList<Record>();
  	 records.add(r);
  	 records.add(r1);
  	 records.add(r2);
  	 
  	 b.setRecords(records);
  	 
  	 
  	 Patient p = new Patient();
  	 p.setId(1);
  	 p.setPname("Mona");
  	 
  	Patient p1 = new Patient();
 	 p1.setId(2);
 	 p1.setPname("Yash");
 	 
 	
 	Patient p2 = new Patient();
 	 p2.setId(3);
 	 p2.setPname("Vrunda");
 	 
 	 r.setP(p);
 	 r1.setP(p1);
 	 r2.setP(p2);


 	 Disease d = new Disease();
 	 d.setId(1);
 	 d.setDname("Dengue");
 	 
 	 Disease d1 = new Disease();
 	 d1.setId(2);
 	 d1.setDname("Maleria");
 	 
 	 Disease d2 = new Disease();
 	 d2.setId(3);
 	 d2.setDname("Nimonia");
 	 
  	 List<Disease>diseases = new ArrayList<Disease>();
  	 diseases.add(d);
  	 diseases.add(d1);
  	 diseases.add(d2);
     
  	 p.setDiseaes(diseases);

     b.setA(a);
     b1.setA(a1);
     b2.setA(a2);
     
  	 h.setBranches(branches);

  	 
  	
  	 
  	 et.begin();
  	 em.persist(h);
  	 em.persist(b);
  	 em.persist(b1);
  	 em.persist(b2);
  	 em.persist(a);
  	 em.persist(a1);
  	 em.persist(a2);
  	 em.persist(r);
  	 em.persist(r1);
  	 em.persist(r2);
  	 em.persist(p);
  	 em.persist(p1);
  	 em.persist(p2);
  	 em.persist(d);
  	 em.persist(d1);
  	 em.persist(d2);
     et.commit();
  	 System.out.println("----------Data Saved-----------");		 
  		}	

  	}


  	 

 
 	 
 	 
 	 
 	 
 	 
 	 
 	 
 	 
 	 


  	 

  	 
  	 
       

    