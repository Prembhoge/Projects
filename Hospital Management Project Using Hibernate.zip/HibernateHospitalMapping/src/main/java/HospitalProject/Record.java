package HospitalProject;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Record {
	@Id
	private int id;
	private String name;
	private double time;
	private String sysmptoms;
	
	@ManyToOne
	Patient p;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getTime() {
		return time;
	}

	public void setTime(double time) {
		this.time = time;
	}

	public String getSysmptoms() {
		return sysmptoms;
	}

	public void setSysmptoms(String sysmptoms) {
		this.sysmptoms = sysmptoms;
	}

	public Patient getP() {
		return p;
	}

	public void setP(Patient p) {
		this.p = p;
	}
	
}